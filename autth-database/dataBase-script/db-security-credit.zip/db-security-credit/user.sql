create table user
(
    id    bigint       not null
        primary key,
    name  varchar(255) null,
    senha varchar(255) null
);

INSERT INTO accessdev.user (id, name, senha) VALUES (1, 'admin', 'J+IC+9VCwqtu7T+4w/Gf4Q==');
INSERT INTO accessdev.user (id, name, senha) VALUES (2, 'caixa', 'oRPiBWJp4ngLybEEP4IwNA==');
INSERT INTO accessdev.user (id, name, senha) VALUES (3, 'supervisor', 'BnX7jKkYwFcpJwAQ5Y2GrA==');
