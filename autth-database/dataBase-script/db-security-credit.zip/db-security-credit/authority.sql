create table authority
(
    auth_id      bigint       not null
        primary key,
    autorize_uri varchar(255) null,
    description  varchar(255) null
);

INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (1, '/credito/list', 'listar creditos');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (2, '/producto/list', 'listar produtos');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (3, '/credito/list/critirea/v2', 'listar creditos');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (4, '/oauth/token', 'login');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (5, '/prestacao/list/credit_id', 'listar prestacao');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (6, '/producto/listar', 'listar prestacoes all');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (7, '/prestacao/list/credit_id', 'lista prestacoes');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (8, '/credito/clientes', 'listar todos clientes');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (9, '/credito/cliente', 'pesquisar cliente');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (10, '/credito/creat', 'crear credito');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (11, '/credito/alterar/estado', 'alterar credito');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (12, '/credito/list/critirea/previes', 'listar credito com paginacao');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (13, '/pagamento/lista', 'listar pagamentos');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (14, '/saldo/intrest', 'consulta do ultimo juro');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (15, '/saldo/capital', 'consulta de capital em vigor');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (16, '/prestacao/create', 'criar prestacao');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (17, '/credito/cliente/create', 'criar cliente');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (18, '/pagamento/create', 'create pagamento');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (19, '/user/list', 'list users');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (20, '/credito/clientes', 'listar clientes');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (21, '/credito/cliente/create', 'criar clientes');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (22, '/credito/cliente', 'consultar detalhes de clientes');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (23, '/producto/create', 'create producto');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (24, '/credito/atualiza', 'aprovar credito/ atualizar');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (25, '/producto/atualizar', 'atualizar producto');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (26, '/producto/find', 'vizualizar os productos na tela de credito');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (27, '/credito/list/findCreditoByClientID', 'filtrar pelo cliente');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (28, '/credito/list/critirea/findByCriteria', 'filtrar por criterio');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (29, '/user/changepass', 'alterar password');
INSERT INTO accessdev.authority (auth_id, autorize_uri, description) VALUES (30, '/credito/cliente/find', 'find client by name');
