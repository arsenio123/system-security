create table role
(
    id        bigint       not null
        primary key,
    descricao varchar(255) null,
    name      varchar(255) null
);

INSERT INTO accessdev.role (id, descricao, name) VALUES (1, 'full access', 'admin');
INSERT INTO accessdev.role (id, descricao, name) VALUES (2, 'read only', 'report');
INSERT INTO accessdev.role (id, descricao, name) VALUES (3, 'adiciona productos e aprovacreditos', 'supervisor');
